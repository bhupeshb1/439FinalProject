#!/usr/bin/env bash
# Download the LOBSTER free sample data.
#
# Source: https://lobsterdata.com/info/DataSamples.php
# Each sample is one trading day (2012-06-21) at level 10.
# Tickers available: AAPL, AMZN, GOOG, INTC, MSFT.
#
# Usage:
#     bash download_data.sh                # downloads AAPL only
#     bash download_data.sh AAPL MSFT INTC # downloads multiple
#
# Files extract into data/lobster/{TICKER}_2012-06-21_*_message_10.csv etc.

set -euo pipefail

TICKERS=("$@")
if [ ${#TICKERS[@]} -eq 0 ]; then
    TICKERS=("AAPL")
fi

DATA_DIR="data/lobster"
mkdir -p "$DATA_DIR"

# LOBSTER serves the free sample under predictable URLs of the form:
#   https://lobsterdata.com/info/sample/LOBSTER_SampleFile_{TICKER}_2012-06-21_10.zip
BASE_URL="https://lobsterdata.com/info/sample"

for TICKER in "${TICKERS[@]}"; do
    ZIP_NAME="LOBSTER_SampleFile_${TICKER}_2012-06-21_10.zip"
    URL="${BASE_URL}/${ZIP_NAME}"
    OUT_PATH="${DATA_DIR}/${ZIP_NAME}"

    if [ -f "${DATA_DIR}/${TICKER}_2012-06-21_34200000_57600000_message_10.csv" ]; then
        echo "[skip] ${TICKER} already extracted."
        continue
    fi

    echo "[download] ${URL}"
    curl -fL -o "${OUT_PATH}" "${URL}" || {
        echo "Download failed for ${TICKER}. The exact URL may have changed."
        echo "Manual download: https://lobsterdata.com/info/DataSamples.php"
        echo "Place the resulting CSVs in ${DATA_DIR}/"
        exit 1
    }

    echo "[extract] ${OUT_PATH}"
    unzip -o "${OUT_PATH}" -d "${DATA_DIR}"
    rm "${OUT_PATH}"
done

echo "Done. Files in ${DATA_DIR}/:"
ls -1 "${DATA_DIR}/"
