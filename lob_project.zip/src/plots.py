"""
Plot generation for paper figures. Saves PDFs to results/figures/ for direct
inclusion in the LaTeX document.

All figures use a consistent style: clean, no chartjunk, large enough labels
to be legible at column width.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.decomposition import PCA

# Consistent style across all figures
plt.rcParams.update({
    "font.family": "serif",
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "legend.fontsize": 9,
    "figure.dpi": 130,
    "savefig.bbox": "tight",
    "savefig.dpi": 200,
})


def plot_k_sweep(sweep: pd.DataFrame, k_star: int, save_path: Path):
    """Two-panel figure: SSE (Elbow) and Silhouette vs k."""
    fig, axes = plt.subplots(1, 2, figsize=(8, 3.2))
    axes[0].plot(sweep["k"], sweep["sse"], marker="o")
    axes[0].axvline(k_star, ls="--", color="red", alpha=0.6, label=f"k*={k_star}")
    axes[0].set_xlabel("Number of clusters K")
    axes[0].set_ylabel("Sum of Squared Errors")
    axes[0].set_title("Elbow Method")
    axes[0].legend()
    axes[0].grid(alpha=0.3)

    axes[1].plot(sweep["k"], sweep["silhouette"], marker="o", color="C1")
    axes[1].axvline(k_star, ls="--", color="red", alpha=0.6, label=f"k*={k_star}")
    axes[1].set_xlabel("Number of clusters K")
    axes[1].set_ylabel("Silhouette score")
    axes[1].set_title("Silhouette Score")
    axes[1].legend()
    axes[1].grid(alpha=0.3)

    fig.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)


def plot_pca_regimes(X: pd.DataFrame, regimes: np.ndarray, save_path: Path,
                     subsample: int = 20_000, seed: int = 42):
    """2D PCA projection of the feature space colored by regime."""
    rng = np.random.default_rng(seed)
    if len(X) > subsample:
        idx = rng.choice(len(X), subsample, replace=False)
        X_sub, r_sub = X.iloc[idx].values, regimes[idx]
    else:
        X_sub, r_sub = X.values, regimes

    # Standardize before PCA
    X_centered = (X_sub - X_sub.mean(axis=0)) / (X_sub.std(axis=0) + 1e-9)
    pca = PCA(n_components=2, random_state=seed)
    proj = pca.fit_transform(X_centered)

    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    palette = sns.color_palette("husl", n_colors=int(r_sub.max()) + 1)
    for r in sorted(np.unique(r_sub)):
        mask = r_sub == r
        ax.scatter(proj[mask, 0], proj[mask, 1], s=4, alpha=0.4,
                   color=palette[r], label=f"Regime {r}")
    ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]:.1%})")
    ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]:.1%})")
    ax.set_title("Microstructure regimes (PCA projection)")
    leg = ax.legend(markerscale=3, loc="best")
    for h in leg.legend_handles:
        h.set_alpha(1.0)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)


def plot_confusion_matrices(
    confusions: dict[str, pd.DataFrame], save_path: Path,
):
    """Side-by-side confusion matrices for each model."""
    n = len(confusions)
    fig, axes = plt.subplots(1, n, figsize=(3.2 * n, 3.2))
    if n == 1:
        axes = [axes]
    for ax, (name, cm) in zip(axes, confusions.items()):
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                    cbar=False, annot_kws={"size": 9})
        ax.set_title(name)
        ax.set_xlabel("Predicted")
        ax.set_ylabel("True")
    fig.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)


def plot_feature_importance(
    importances: dict[str, pd.Series], save_path: Path, top_n: int = 12,
):
    """Side-by-side feature-importance bars for each model."""
    n = len(importances)
    fig, axes = plt.subplots(1, n, figsize=(4 * n, 4), sharey=False)
    if n == 1:
        axes = [axes]
    for ax, (name, imp) in zip(axes, importances.items()):
        top = imp.head(top_n)[::-1]  # reverse so highest is on top
        ax.barh(range(len(top)), top.values, color="C0")
        ax.set_yticks(range(len(top)))
        ax.set_yticklabels(top.index, fontsize=8)
        ax.set_title(name)
        ax.set_xlabel("Importance")
        ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)


def plot_transition_heatmap(transition: pd.DataFrame, save_path: Path):
    """Heatmap of regime transition probabilities."""
    fig, ax = plt.subplots(figsize=(5, 4))
    sns.heatmap(transition.values, annot=True, fmt=".2f", cmap="viridis",
                ax=ax, cbar_kws={"label": "P(to | from)"})
    ax.set_xticklabels([s.replace("to_r", "R") for s in transition.columns])
    ax.set_yticklabels([s.replace("from_r", "R") for s in transition.index], rotation=0)
    ax.set_xlabel("To regime")
    ax.set_ylabel("From regime")
    ax.set_title("Regime transition matrix")
    fig.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)


def plot_horizon_comparison(results_df: pd.DataFrame, save_path: Path):
    """Macro-F1 vs horizon, one line per model."""
    fig, ax = plt.subplots(figsize=(5.5, 4))
    for model in results_df["model"].unique():
        sub = results_df[results_df["model"] == model].sort_values("horizon")
        ax.plot(sub["horizon"], sub["macro_f1"], marker="o", label=model)
    ax.set_xlabel("Prediction horizon (events)")
    ax.set_ylabel("Macro-F1")
    ax.set_title("Performance vs horizon")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)


def plot_per_regime_f1(per_regime: pd.DataFrame, save_path: Path):
    """Per-regime F1 comparing GBM-blind vs GBM-cond."""
    fig, ax = plt.subplots(figsize=(5.5, 3.6))
    width = 0.35
    x = np.arange(len(per_regime))
    ax.bar(x - width/2, per_regime["macro_f1_blind"], width, label="GBM-blind")
    ax.bar(x + width/2, per_regime["macro_f1_cond"], width, label="GBM-cond")
    ax.set_xticks(x)
    ax.set_xticklabels([f"R{int(r)}" for r in per_regime["regime"]])
    ax.set_ylabel("Macro-F1")
    ax.set_xlabel("Regime")
    ax.set_title("Per-regime macro-F1")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)
