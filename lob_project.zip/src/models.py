"""
Four model variants for short-horizon mid-price direction prediction.

1. LR-blind   : Logistic regression on engineered features
2. GBM-blind  : LightGBM on engineered features
3. GBM-feat   : LightGBM on engineered features + one-hot regime ID
4. GBM-cond   : One LightGBM per regime, gated by regime assignment

All use class_weight='balanced' / sample_weight inversely proportional to
training class frequencies, since labels are heavily imbalanced toward the
stationary class.
"""

from __future__ import annotations

from dataclasses import dataclass

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_sample_weight


# Default LightGBM hyperparameters. Modest because dataset is single-day and
# we want to leave room for clear over- vs. under-fitting in ablations.
LGB_PARAMS = dict(
    n_estimators=200,
    learning_rate=0.05,
    num_leaves=31,
    min_child_samples=50,
    reg_alpha=0.1,
    reg_lambda=0.1,
    objective="multiclass",
    num_class=3,
    random_state=42,
    verbose=-1,
)


def _y_to_idx(y: np.ndarray | pd.Series) -> np.ndarray:
    """Map labels {-1, 0, 1} to integer indices {0, 1, 2} for LightGBM."""
    y = np.asarray(y)
    return (y + 1).astype(int)


def _idx_to_y(idx: np.ndarray) -> np.ndarray:
    return idx.astype(int) - 1


@dataclass
class TrainedModel:
    """Wrapper around a trained model with a uniform predict_proba interface
    that returns columns ordered as [P(-1), P(0), P(+1)]."""
    name: str
    predict_proba: callable           # X -> (n, 3)
    predict: callable                 # X -> (n,) in {-1, 0, 1}
    feature_importance: pd.Series | None = None


# ---------- Variant 1: LR-blind ----------

def train_lr_blind(X_train: pd.DataFrame, y_train: np.ndarray) -> TrainedModel:
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_train.values)
    # sklearn >=1.5 removed the multi_class arg; LogisticRegression is multinomial
    # by default for multi-class problems.
    clf = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)
    clf.fit(X_scaled, _y_to_idx(y_train))

    def predict_proba(X: pd.DataFrame) -> np.ndarray:
        return clf.predict_proba(scaler.transform(X[X_train.columns].values))

    def predict(X: pd.DataFrame) -> np.ndarray:
        return _idx_to_y(clf.predict(scaler.transform(X[X_train.columns].values)))

    # Magnitude of coefficients across classes as importance proxy
    coef_importance = pd.Series(
        np.abs(clf.coef_).mean(axis=0), index=X_train.columns
    ).sort_values(ascending=False)

    return TrainedModel(name="LR-blind", predict_proba=predict_proba,
                        predict=predict, feature_importance=coef_importance)


# ---------- Variant 2: GBM-blind ----------

def train_gbm_blind(X_train: pd.DataFrame, y_train: np.ndarray, **lgb_kwargs) -> TrainedModel:
    sample_weight = compute_sample_weight("balanced", _y_to_idx(y_train))
    params = {**LGB_PARAMS, **lgb_kwargs}
    clf = lgb.LGBMClassifier(**params)
    clf.fit(X_train.values, _y_to_idx(y_train), sample_weight=sample_weight)

    feat_cols = list(X_train.columns)

    def predict_proba(X: pd.DataFrame) -> np.ndarray:
        return clf.predict_proba(X[feat_cols].values)

    def predict(X: pd.DataFrame) -> np.ndarray:
        return _idx_to_y(clf.predict(X[feat_cols].values))

    importance = pd.Series(clf.feature_importances_, index=feat_cols).sort_values(ascending=False)
    return TrainedModel(name="GBM-blind", predict_proba=predict_proba,
                        predict=predict, feature_importance=importance)


# ---------- Variant 3: GBM-feat ----------

def _add_regime_features(X: pd.DataFrame, regimes: np.ndarray, k: int) -> pd.DataFrame:
    one_hot = pd.DataFrame(
        np.zeros((len(X), k)),
        columns=[f"regime_{i}" for i in range(k)],
        index=X.index,
    )
    for i in range(k):
        one_hot.iloc[:, i] = (regimes == i).astype(float)
    return pd.concat([X, one_hot], axis=1)


def train_gbm_feat(
    X_train: pd.DataFrame, y_train: np.ndarray, regimes_train: np.ndarray, k: int,
    **lgb_kwargs,
) -> TrainedModel:
    X_aug = _add_regime_features(X_train, regimes_train, k)
    sample_weight = compute_sample_weight("balanced", _y_to_idx(y_train))
    params = {**LGB_PARAMS, **lgb_kwargs}
    clf = lgb.LGBMClassifier(**params)
    clf.fit(X_aug.values, _y_to_idx(y_train), sample_weight=sample_weight)

    feat_cols = list(X_aug.columns)
    base_cols = list(X_train.columns)

    def predict_proba_with_regimes(X: pd.DataFrame, regimes: np.ndarray) -> np.ndarray:
        X_aug_test = _add_regime_features(X[base_cols], regimes, k)
        return clf.predict_proba(X_aug_test.values)

    def predict_with_regimes(X: pd.DataFrame, regimes: np.ndarray) -> np.ndarray:
        X_aug_test = _add_regime_features(X[base_cols], regimes, k)
        return _idx_to_y(clf.predict(X_aug_test.values))

    importance = pd.Series(clf.feature_importances_, index=feat_cols).sort_values(ascending=False)

    # Wrap in a TrainedModel-like object but the predict signatures take regimes.
    # We attach the regime-aware methods directly.
    tm = TrainedModel(name="GBM-feat", predict_proba=None, predict=None,
                      feature_importance=importance)
    tm.predict_proba_regimes = predict_proba_with_regimes
    tm.predict_regimes = predict_with_regimes
    return tm


# ---------- Variant 4: GBM-cond ----------

class GBMConditional:
    """One LightGBM per regime, gated at inference by the regime assignment of
    the test point. If a regime has too few samples in training we fall back to
    a global model."""

    def __init__(self, k: int, min_samples_per_regime: int = 200, **lgb_kwargs):
        self.k = k
        self.min_samples_per_regime = min_samples_per_regime
        self.lgb_kwargs = lgb_kwargs
        self.models: dict[int, lgb.LGBMClassifier] = {}
        self.fallback: lgb.LGBMClassifier | None = None
        self.feature_cols: list[str] | None = None

    def fit(self, X: pd.DataFrame, y: np.ndarray, regimes: np.ndarray):
        self.feature_cols = list(X.columns)
        params = {**LGB_PARAMS, **self.lgb_kwargs}

        # Always train a global fallback so unseen-regime situations are safe
        sample_weight_all = compute_sample_weight("balanced", _y_to_idx(y))
        self.fallback = lgb.LGBMClassifier(**params)
        self.fallback.fit(X.values, _y_to_idx(y), sample_weight=sample_weight_all)

        for r in range(self.k):
            mask = regimes == r
            n = int(mask.sum())
            if n < self.min_samples_per_regime:
                # Too few examples — use the global fallback for this regime
                self.models[r] = self.fallback
                continue
            X_r = X.iloc[mask].values
            y_r = _y_to_idx(y[mask])
            # Ensure all 3 classes present; if not, fall back
            if len(np.unique(y_r)) < 3:
                self.models[r] = self.fallback
                continue
            sw = compute_sample_weight("balanced", y_r)
            clf = lgb.LGBMClassifier(**params)
            clf.fit(X_r, y_r, sample_weight=sw)
            self.models[r] = clf
        return self

    def predict_proba(self, X: pd.DataFrame, regimes: np.ndarray) -> np.ndarray:
        out = np.zeros((len(X), 3))
        X_arr = X[self.feature_cols].values
        for r in range(self.k):
            mask = regimes == r
            if mask.sum() == 0:
                continue
            model = self.models.get(r, self.fallback)
            out[mask] = model.predict_proba(X_arr[mask])
        return out

    def predict(self, X: pd.DataFrame, regimes: np.ndarray) -> np.ndarray:
        proba = self.predict_proba(X, regimes)
        return _idx_to_y(np.argmax(proba, axis=1))

    def aggregate_feature_importance(self) -> pd.Series:
        """Average feature importance across regime-specific models that were
        actually trained (not fallbacks)."""
        importances = []
        seen_models = set()
        for r, model in self.models.items():
            if id(model) in seen_models or model is self.fallback:
                continue
            seen_models.add(id(model))
            importances.append(model.feature_importances_)
        if not importances:
            return pd.Series(self.fallback.feature_importances_, index=self.feature_cols)
        avg = np.mean(importances, axis=0)
        return pd.Series(avg, index=self.feature_cols).sort_values(ascending=False)


def train_gbm_cond(
    X_train: pd.DataFrame, y_train: np.ndarray, regimes_train: np.ndarray, k: int,
    min_samples_per_regime: int = 200, **lgb_kwargs,
) -> GBMConditional:
    model = GBMConditional(k=k, min_samples_per_regime=min_samples_per_regime, **lgb_kwargs)
    model.fit(X_train, y_train, regimes_train)
    return model


if __name__ == "__main__":
    from load import synthesize_lobster_day, filter_session
    from features import compute_features
    from label import compute_labels
    from cluster import fit_clustering, assign_regimes

    df = synthesize_lobster_day(n_events=30_000)
    df = filter_session(df)
    X = compute_features(df, window=100)
    y = compute_labels(df, horizon=50, theta=0.005)
    valid = ~(X.isna().any(axis=1) | y.isna())
    X, y = X[valid], y[valid]

    n = len(X)
    split = int(n * 0.8)
    X_tr, X_te = X.iloc[:split], X.iloc[split:]
    y_tr, y_te = y.iloc[:split].values, y.iloc[split:].values

    art = fit_clustering(X_tr, k=4)
    r_tr, r_te = assign_regimes(art, X_tr), assign_regimes(art, X_te)

    print(f"Train: {len(X_tr)}  Test: {len(X_te)}")
    print(f"Train class dist: {pd.Series(y_tr).value_counts(normalize=True).to_dict()}")

    m1 = train_lr_blind(X_tr, y_tr)
    print(f"\n{m1.name}: predicted class dist = {pd.Series(m1.predict(X_te)).value_counts().to_dict()}")

    m2 = train_gbm_blind(X_tr, y_tr)
    print(f"{m2.name}: predicted class dist = {pd.Series(m2.predict(X_te)).value_counts().to_dict()}")

    m3 = train_gbm_feat(X_tr, y_tr, r_tr, k=4)
    print(f"{m3.name}: predicted class dist = {pd.Series(m3.predict_regimes(X_te, r_te)).value_counts().to_dict()}")

    m4 = train_gbm_cond(X_tr, y_tr, r_tr, k=4)
    print(f"GBM-cond: predicted class dist = {pd.Series(m4.predict(X_te, r_te)).value_counts().to_dict()}")
