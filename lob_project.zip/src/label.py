"""
Label construction for short-horizon mid-price direction prediction.

For horizon k (in events), label of snapshot t is:
    +1 if mid[t+k] > mid[t] + theta
    -1 if mid[t+k] < mid[t] - theta
     0 otherwise

theta is set to half a tick by default (so sub-tick noise is classified
as stationary).
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def compute_labels(
    df: pd.DataFrame,
    horizon: int = 50,
    theta: float = 0.005,  # half a penny tick
) -> pd.Series:
    """Return a Series of {-1, 0, +1} labels aligned with df. The last `horizon`
    rows will be NaN since their future is unobserved.
    """
    mid = (df["ap1"] + df["bp1"]) / 2.0
    future = mid.shift(-horizon)
    diff = future - mid
    label = pd.Series(0, index=df.index, dtype="float64")
    label[diff > theta] = 1.0
    label[diff < -theta] = -1.0
    label[future.isna()] = np.nan
    return label


def label_distribution(label: pd.Series) -> dict[str, float]:
    """Return the empirical class distribution as fractions."""
    valid = label.dropna()
    if len(valid) == 0:
        return {"down": 0.0, "stationary": 0.0, "up": 0.0}
    return {
        "down": float((valid == -1).mean()),
        "stationary": float((valid == 0).mean()),
        "up": float((valid == 1).mean()),
    }


if __name__ == "__main__":
    from load import synthesize_lobster_day, filter_session

    df = synthesize_lobster_day(n_events=20_000)
    df = filter_session(df)
    for h in [10, 50, 100]:
        labels = compute_labels(df, horizon=h, theta=0.005)
        dist = label_distribution(labels)
        print(f"Horizon {h:3d}: down={dist['down']:.3f}, "
              f"stationary={dist['stationary']:.3f}, up={dist['up']:.3f}")
