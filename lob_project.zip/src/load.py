"""
LOBSTER data loader.

LOBSTER provides two synchronized CSV files per ticker per day:
- *_message_10.csv : every event in the order book
- *_orderbook_10.csv : LOB state immediately after each event

Free sample: https://lobsterdata.com/info/DataSamples.php
File naming: {TICKER}_{YYYY-MM-DD}_{START_MS}_{END_MS}_{TYPE}_{LEVELS}.csv
where START/END are milliseconds after midnight (34200000 = 09:30:00).
"""

from __future__ import annotations

import os
from pathlib import Path

import numpy as np
import pandas as pd

# LOBSTER message columns (no header in source files)
MESSAGE_COLS = ["time", "type", "order_id", "size", "price", "direction"]

# Message types
TYPE_SUBMIT = 1          # New limit order
TYPE_CANCEL_PARTIAL = 2  # Partial cancel
TYPE_CANCEL_TOTAL = 3    # Full cancel
TYPE_EXEC_VISIBLE = 4    # Execution of a visible limit order
TYPE_EXEC_HIDDEN = 5     # Execution of a hidden order
TYPE_CROSS_TRADE = 6     # Cross trade (auction)
TYPE_HALT = 7            # Trading halt indicator


def orderbook_columns(levels: int = 10) -> list[str]:
    """Generate orderbook column names. LOBSTER ordering: ask_price_i, ask_size_i,
    bid_price_i, bid_size_i, alternating per level."""
    cols = []
    for i in range(1, levels + 1):
        cols += [f"ap{i}", f"av{i}", f"bp{i}", f"bv{i}"]
    return cols


def load_lobster_day(
    data_dir: str | Path,
    ticker: str,
    date: str,
    levels: int = 10,
    start_ms: int = 34200000,
    end_ms: int = 57600000,
) -> pd.DataFrame:
    """Load one trading day of LOBSTER data and return a single dataframe with
    one row per event, columns = [time, type, order_id, size, price, direction,
    ap1, av1, bp1, bv1, ..., ap10, av10, bp10, bv10].

    Prices in LOBSTER are in dollars * 10000. We convert to dollars.
    """
    data_dir = Path(data_dir)
    base = f"{ticker}_{date}_{start_ms}_{end_ms}"
    msg_path = data_dir / f"{base}_message_{levels}.csv"
    ob_path = data_dir / f"{base}_orderbook_{levels}.csv"

    if not msg_path.exists():
        raise FileNotFoundError(
            f"Could not find {msg_path}. Did you run `bash download_data.sh`?"
        )
    if not ob_path.exists():
        raise FileNotFoundError(f"Could not find {ob_path}.")

    messages = pd.read_csv(msg_path, header=None, names=MESSAGE_COLS)
    ob_cols = orderbook_columns(levels)
    orderbook = pd.read_csv(ob_path, header=None, names=ob_cols)

    if len(messages) != len(orderbook):
        raise ValueError(
            f"Message ({len(messages)}) and orderbook ({len(orderbook)}) "
            f"row counts do not match."
        )

    df = pd.concat([messages.reset_index(drop=True), orderbook.reset_index(drop=True)], axis=1)

    # Convert prices from int (USD * 10000) to float USD
    price_cols = ["price"] + [f"ap{i}" for i in range(1, levels + 1)] + [
        f"bp{i}" for i in range(1, levels + 1)
    ]
    for c in price_cols:
        df[c] = df[c] / 10000.0

    return df


def filter_session(df: pd.DataFrame, trim_minutes: int = 5) -> pd.DataFrame:
    """Drop the first and last `trim_minutes` of the trading day to avoid
    open/close auction artifacts."""
    open_time = 9 * 3600 + 30 * 60          # 09:30:00 in seconds-after-midnight
    close_time = 16 * 3600                  # 16:00:00
    trim = trim_minutes * 60
    mask = (df["time"] >= open_time + trim) & (df["time"] <= close_time - trim)
    return df.loc[mask].reset_index(drop=True)


def synthesize_lobster_day(
    n_events: int = 200_000,
    levels: int = 10,
    seed: int = 42,
) -> pd.DataFrame:
    """Generate a plausible-looking synthetic LOBSTER day for unit testing.
    NOT for use in real experiments — only for verifying the pipeline runs.
    """
    rng = np.random.default_rng(seed)
    open_time = 9 * 3600 + 30 * 60
    close_time = 16 * 3600

    # Event times spread across the trading day, sorted
    times = np.sort(rng.uniform(open_time, close_time, n_events))

    # Mid-price as a random walk in tick units, starting at $100
    tick = 0.01
    mid_walk = np.cumsum(rng.normal(0, 0.5, n_events)) * tick + 100.0
    mid_walk = np.maximum(mid_walk, 50.0)

    # Spread varies between 1 and 5 ticks
    spread_ticks = rng.integers(1, 6, n_events)
    half_spread = spread_ticks * tick / 2

    bp1 = mid_walk - half_spread
    ap1 = mid_walk + half_spread

    # Build orderbook columns
    ob = {}
    for i in range(1, levels + 1):
        ob[f"ap{i}"] = ap1 + (i - 1) * tick
        ob[f"bp{i}"] = bp1 - (i - 1) * tick
        ob[f"av{i}"] = rng.integers(100, 1000, n_events)
        ob[f"bv{i}"] = rng.integers(100, 1000, n_events)

    msg = {
        "time": times,
        "type": rng.choice([1, 2, 3, 4], n_events, p=[0.5, 0.2, 0.2, 0.1]),
        "order_id": np.arange(n_events) + 1_000_000,
        "size": rng.integers(100, 500, n_events),
        "price": (ap1 + rng.normal(0, tick, n_events)),
        "direction": rng.choice([-1, 1], n_events),
    }

    return pd.DataFrame({**msg, **ob})


if __name__ == "__main__":
    # Smoke test
    df = synthesize_lobster_day(n_events=10_000)
    df = filter_session(df)
    print(f"Synthesized {len(df)} events")
    print(df.head(3))
    print(f"Columns: {list(df.columns)[:8]}...")
