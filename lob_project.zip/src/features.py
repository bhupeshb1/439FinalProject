"""
Feature engineering for limit order book snapshots.

Each row is one event. From each row we compute:
- Static features: spread, micro-price displacement, depth imbalance at L1/L5,
  total displayed depth, slope of bid/ask curves
- Dynamic (rolling) features over the last W events: realized vol of returns,
  order-flow imbalance, trade intensity, mean spread

All rolling computations use ONLY past data (closed='left' equivalent) to avoid
look-ahead bias.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

# Names of the feature columns produced. Keep this list in sync with `compute_features`.
STATIC_FEATURES = [
    "spread",
    "imb_l1",
    "imb_l5",
    "micro_disp",
    "log_total_depth",
    "bid_slope",
    "ask_slope",
]
DYNAMIC_FEATURES = [
    "rv_w",
    "ofi_w",
    "trade_intensity_w",
    "mean_spread_w",
    "ret_w",
]
FEATURE_COLS = STATIC_FEATURES + DYNAMIC_FEATURES


def compute_mid(df: pd.DataFrame) -> pd.Series:
    return (df["ap1"] + df["bp1"]) / 2.0


def compute_static_features(df: pd.DataFrame, depth_levels: int = 5) -> pd.DataFrame:
    """All features that depend on a single snapshot only.

    Returns a dataframe with columns matching STATIC_FEATURES, indexed like df.
    """
    out = pd.DataFrame(index=df.index)

    # Spread
    out["spread"] = df["ap1"] - df["bp1"]

    # Level-1 imbalance
    denom_l1 = df["bv1"] + df["av1"]
    out["imb_l1"] = np.where(denom_l1 > 0, (df["bv1"] - df["av1"]) / denom_l1, 0.0)

    # Level-5 cumulative imbalance
    bid_depth = sum(df[f"bv{i}"] for i in range(1, depth_levels + 1))
    ask_depth = sum(df[f"av{i}"] for i in range(1, depth_levels + 1))
    denom_l5 = bid_depth + ask_depth
    out["imb_l5"] = np.where(denom_l5 > 0, (bid_depth - ask_depth) / denom_l5, 0.0)

    # Micro-price displacement: (b1*va1 + a1*vb1) / (vb1 + va1) - mid
    mid = compute_mid(df)
    micro_denom = df["bv1"] + df["av1"]
    micro_price = np.where(
        micro_denom > 0,
        (df["bp1"] * df["av1"] + df["ap1"] * df["bv1"]) / micro_denom,
        mid,
    )
    out["micro_disp"] = micro_price - mid

    # Log of total displayed depth at top 5 levels
    out["log_total_depth"] = np.log1p(bid_depth + ask_depth)

    # Slope of bid/ask curves: how fast price drops away from best
    # bid_slope = (bp1 - bp5) / 4 (positive number, larger = steeper drop)
    bp_last = df[f"bp{depth_levels}"]
    ap_last = df[f"ap{depth_levels}"]
    out["bid_slope"] = (df["bp1"] - bp_last) / max(depth_levels - 1, 1)
    out["ask_slope"] = (ap_last - df["ap1"]) / max(depth_levels - 1, 1)

    return out


def compute_dynamic_features(
    df: pd.DataFrame,
    window: int = 100,
) -> pd.DataFrame:
    """Rolling-window features. Uses ONLY past data: shift by 1 before rolling.

    Returns a dataframe with columns matching DYNAMIC_FEATURES, indexed like df.
    """
    out = pd.DataFrame(index=df.index)
    mid = compute_mid(df)

    # Log returns of mid-price, shifted to avoid look-ahead
    log_ret = np.log(mid).diff()

    # Realized volatility over window (std of log returns)
    out["rv_w"] = log_ret.shift(1).rolling(window, min_periods=10).std()

    # Mean log-return over window (drift signal)
    out["ret_w"] = log_ret.shift(1).rolling(window, min_periods=10).mean()

    # Order-flow imbalance (signed depth change at L1)
    # Positive = bid side pressure; negative = ask side pressure.
    bp1, bv1 = df["bp1"], df["bv1"]
    ap1, av1 = df["ap1"], df["av1"]

    # Bid OFI: if bp went up, +bv1; if bp went down, -prev(bv1); if same, +(bv1-prev(bv1))
    bp_diff = bp1.diff()
    bv_diff = bv1.diff()
    bid_ofi = np.where(
        bp_diff > 0, bv1,
        np.where(bp_diff < 0, -bv1.shift(1).fillna(0), bv_diff.fillna(0))
    )
    # Ask OFI: opposite sign convention
    ap_diff = ap1.diff()
    av_diff = av1.diff()
    ask_ofi = np.where(
        ap_diff > 0, -av1.shift(1).fillna(0),
        np.where(ap_diff < 0, av1, -av_diff.fillna(0))
    )
    ofi = pd.Series(bid_ofi + ask_ofi, index=df.index)
    out["ofi_w"] = ofi.shift(1).rolling(window, min_periods=10).sum()

    # Trade intensity: number of executions per second over window
    is_trade = df["type"].isin([4, 5]).astype(float)
    n_trades = is_trade.shift(1).rolling(window, min_periods=10).sum()
    time_span = df["time"].diff().shift(1).rolling(window, min_periods=10).sum().clip(lower=1e-6)
    out["trade_intensity_w"] = n_trades / time_span

    # Mean spread over window
    spread = df["ap1"] - df["bp1"]
    out["mean_spread_w"] = spread.shift(1).rolling(window, min_periods=10).mean()

    return out


def compute_features(df: pd.DataFrame, window: int = 100, depth_levels: int = 5) -> pd.DataFrame:
    """Compute all features and return them concatenated. Drops rows with NaN
    (which appear at the start of the day before the rolling window has filled)."""
    static = compute_static_features(df, depth_levels=depth_levels)
    dynamic = compute_dynamic_features(df, window=window)
    feats = pd.concat([static, dynamic], axis=1)
    return feats


if __name__ == "__main__":
    from load import synthesize_lobster_day, filter_session

    df = synthesize_lobster_day(n_events=20_000)
    df = filter_session(df)
    feats = compute_features(df, window=100)
    print(f"Computed {feats.shape[1]} features over {len(feats)} snapshots")
    print(f"NaN count per feature:\n{feats.isna().sum()}")
    print(f"\nFeature stats:\n{feats.describe().T[['mean', 'std', 'min', 'max']]}")
